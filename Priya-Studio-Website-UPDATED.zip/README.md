# PRIYA STUDIO — Updated Website

A responsive e-commerce front-end for Priya Studio featuring:
- Resin Art
- T-Shirts
- Jewellery
- Personalized Gifts
- Premium blush/cream/champagne-gold visual identity
- Generated Priya Studio logo
- Generated visual asset pack
- Responsive mobile layout
- Cart drawer and basic interactions

## Files
- index.html
- style.css
- script.js
- assets/logo.svg
- assets/*.jpg — generated visual assets used by the website

## Run
Open `index.html` in a browser.

## Before launch
Replace generated visuals with your own licensed product photography where appropriate, connect your real product catalog/inventory, payment gateway, shipping rules, WhatsApp/contact details, policies, analytics and domain.
